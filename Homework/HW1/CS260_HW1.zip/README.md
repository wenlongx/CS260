# CS 260 Homework 1
To run the code, go into your terminal and navigate to the directory that contains `HW1.py`. Run the following command to train and test the logistic regression and linera SVM classifiers.
```
python3 HW1.py
```
To generate the plots for the report, uncomment the lines marked in the file `HW1.py` at the bottom of the main function, then run the same command as above.
